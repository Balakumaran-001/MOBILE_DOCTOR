package com.mobiledoctor.app

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.StatFs
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            sendPermissions()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(AndroidBridge(this@MainActivity), "AndroidDoctor")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    private fun requestAllSafePermissions() {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        list += Manifest.permission.ACCESS_FINE_LOCATION
        list += Manifest.permission.ACCESS_COARSE_LOCATION
        list += Manifest.permission.RECORD_AUDIO
        if (list.isNotEmpty()) permissionLauncher.launch(list.toTypedArray())
    }

    private fun sendPermissions() {
        val data = JSONObject().apply {
            put("notifications", if (Build.VERSION.SDK_INT < 33) "granted" else state(Manifest.permission.POST_NOTIFICATIONS))
            put("location", state(Manifest.permission.ACCESS_FINE_LOCATION))
            put("microphone", state(Manifest.permission.RECORD_AUDIO))
            put("vibration", if (getSystemService(VIBRATOR_SERVICE) != null) "available" else "unsupported")
        }
        web.evaluateJavascript("window.nativePermissions && window.nativePermissions(${JSONObject.quote(data.toString())})", null)
    }

    private fun state(permission: String): String =
        if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) "granted" else "denied"

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("mobile_doctor", "Mobile Doctor", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    inner class AndroidBridge(private val ctx: Context) {
        @JavascriptInterface
        fun requestPermissions() = runOnUiThread { requestAllSafePermissions() }

        @JavascriptInterface
        fun batteryInfo(): String {
            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
            val intent = registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val temp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            val voltage = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val health = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
            val capacity = if (Build.VERSION.SDK_INT >= 21)
                bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) else level
            return JSONObject().apply {
                put("level", if (scale > 0) level * 100 / scale else -1)
                put("capacity", capacity)
                put("temperatureC", if (temp >= 0) temp / 10.0 else JSONObject.NULL)
                put("voltageMv", voltage)
                put("charging", charging)
                put("status", status)
                put("health", health)
            }.toString()
        }

        @JavascriptInterface
        fun networkInfo(): String {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork
            val c = cm.getNetworkCapabilities(n)
            return JSONObject().apply {
                put("online", c != null)
                put("wifi", c?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true)
                put("cellular", c?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true)
                put("metered", cm.isActiveNetworkMetered)
                put("downstreamKbps", c?.linkDownstreamBandwidthKbps ?: -1)
                put("upstreamKbps", c?.linkUpstreamBandwidthKbps ?: -1)
            }.toString()
        }

        @JavascriptInterface
        fun deviceInfo(): String {
            val dm = resources.displayMetrics
            val stat = StatFs(filesDir.path)
            val free = stat.availableBytes
            return JSONObject().apply {
                put("manufacturer", Build.MANUFACTURER)
                put("model", Build.MODEL)
                put("android", Build.VERSION.RELEASE)
                put("sdk", Build.VERSION.SDK_INT)
                put("screenWidth", dm.widthPixels)
                put("screenHeight", dm.heightPixels)
                put("density", dm.density)
                put("freeStorageBytes", free)
                put("cores", Runtime.getRuntime().availableProcessors())
            }.toString()
        }

        @JavascriptInterface
        fun vibrate() {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(180, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") v.vibrate(180)
        }

        @JavascriptInterface
        fun usageAccessGranted(): Boolean =
            try {
                val appOps = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
                val mode = appOps.checkOpNoThrow(
                    "android:get_usage_stats",
                    android.os.Process.myUid(),
                    packageName
                )
                mode == android.app.AppOpsManager.MODE_ALLOWED
            } catch (_: Exception) { false }

        @JavascriptInterface
        fun openUsageAccessSettings() {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        @JavascriptInterface
        fun openBatteryOptimizationSettings() {
            startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        }
    }
}
