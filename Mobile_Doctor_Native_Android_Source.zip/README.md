# Mobile Doctor — Native Android + Web UI

This project wraps the Mobile Doctor liquid-glass web UI inside a native Android app and adds a Kotlin bridge for real Android device data.

## Native features included
- Runtime Android permission flow for notifications, location and microphone.
- BatteryManager integration: battery level/capacity, charging state, battery temperature, voltage and Android-reported battery health state.
- ConnectivityManager integration: online state, Wi-Fi/mobile transport and link bandwidth hints.
- Native display/device information.
- Native vibration test.
- Usage Access helper entry point (requires the user to enable it in Android Settings).
- Android battery settings helper entry point.

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build > Build App Bundle(s) / APK(s) > Build APK(s).

A signed release APK requires your own signing key.

## Important limits
Android deliberately restricts some diagnostics. An app cannot universally control the physical power button or force charging to stop at 80%/start at 25%. Exact charging watts, detailed battery health/cycle data and malware scanning can vary by OEM/device and may require privileged/OEM APIs or a dedicated security engine. Usage statistics require the user to grant Usage Access in Settings.

The app reports what Android actually exposes instead of inventing hardware results.
