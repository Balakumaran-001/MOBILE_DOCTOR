const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={issues:[],battery:null,restTimer:null};
const tests=[
["battery","🔋","Battery","Battery level, charging state and available battery API data."],
["network","🌐","Network","Connection type and online/offline state."],
["charging","⚡","Charging","Charging state and charge-rate estimation when supported."],
["display","🖥️","Display","Screen dimensions, pixel ratio and display test."],
["sound","🔊","Sound","Browser audio-output test."],
["security","🛡️","Security","Browser-safe security checks; installed-app malware scanning needs native OS privileges."],
["performance","🚀","Performance","CPU/memory/browser benchmark."],
["device","📱","Device","Browser/device capability information."]
];
function toast(x){const t=$("#toast");t.textContent=x;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2500)}
function cardHTML(t){return `<div class="card glass" id="card-${t[0]}"><div class="icon">${t[1]}</div><h3>${t[2]}</h3><p id="desc-${t[0]}">${t[3]}</p></div>`}
$("#cards").innerHTML=tests.map(cardHTML).join("");
function issue(type,title,detail){state.issues.push({type,title,detail});renderReport()}
function renderReport(){const r=$("#report");if(!state.issues.length){r.innerHTML='<div class="empty">No issues reported yet.</div>';return}r.innerHTML=state.issues.slice(-30).reverse().map(x=>`<div class="issue ${x.type}"><b>${x.title}</b><div>${x.detail}</div></div>`).join("")}
function mark(id,status,desc){const c=$("#card-"+id);c.classList.remove("ok","warn","bad");c.classList.add(status);$("#desc-"+id).textContent=desc}
async function getBattery(){if(!navigator.getBattery)return null;try{return await navigator.getBattery()}catch{return null}}
async function batteryTest(){
 const b=state.battery||await getBattery();state.battery=b;if(!b){mark("battery","warn","Battery API is unavailable in this browser. Native APK can expose more battery data.");issue("warn","Battery API unavailable","Install/run the native Android build for deeper battery telemetry.");return}
 const level=Math.round(b.level*100), ch=b.charging;
 $("#mBattery").textContent=level+"%";$("#mCharging").textContent=ch?"Charging":"Not charging";
 mark("battery",level<20?"warn":"ok",`${level}% • ${ch?"Charging":"Not charging"}${b.chargingTime<Infinity?" • "+Math.round(b.chargingTime/60)+" min to full":""}`);
 if(level<25) issue("warn","Low battery",`Battery is at ${level}%. Consider charging.`)
 if(level>=Number(localStorage.highLimit||80)) issue("warn","Charge limit reached",`Battery reached ${level}%. Your preference is ${localStorage.highLimit||80}%. Android system charge limiting is not controlled by a web app.`);
}
async function networkTest(){
 const online=navigator.onLine; const c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;
 $("#mNetwork").textContent=online?"Online":"Offline";$("#mConnection").textContent=c?.effectiveType||"Unknown";
 mark("network",online?"ok":"bad",online?`Online • ${c?.effectiveType||"connection type unavailable"}`:"Offline");
 if(!online) issue("bad","Network offline","The phone currently reports no network connection.");
}
function deviceTest(){
 const d=`${screen.width}×${screen.height} • DPR ${devicePixelRatio} • ${navigator.hardwareConcurrency||"?"} CPU threads`;
 $("#mScreen").textContent=`${screen.width}×${screen.height}`;$("#mMemory").textContent=navigator.deviceMemory?`${navigator.deviceMemory} GB`:"Unknown";
 mark("device","ok",d);mark("display","ok",`${d}. Full hardware display diagnostics need native Android APIs.`);
}
function securityTest(){
 const secure=location.protocol==="https:"||location.hostname==="localhost";
 mark("security",secure?"ok":"warn",secure?"Secure context available.":"Use HTTPS for secure browser APIs.");
 issue("warn","Malware scan scope","A PWA cannot scan all installed apps/files. Native Android antivirus-style scanning requires OS/package/file permissions and an actual malware engine.");
}
function soundTest(){
 try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)throw 0;const a=new AC(),o=a.createOscillator(),g=a.createGain();o.frequency.value=880;g.gain.value=.03;o.connect(g);g.connect(a.destination);o.start();setTimeout(()=>{o.stop();a.close()},350);mark("sound","ok","Played a short audio test tone. Check your speaker manually.");}
 catch{mark("sound","warn","Audio test is unavailable in this browser.")}
}
function vibrationTest(){if(navigator.vibrate){navigator.vibrate([120,80,120]);mark("sound","ok","Vibration command sent. Check the phone's vibration motor.");}else toast("Vibration API unavailable")}
function displayTest(){$("#displayModal").classList.remove("hidden")}
async function speedTest(){
 const btn=$("#speedTest");btn.disabled=true;$("#speedResult").textContent="Testing…";
 const bytes=2*1024*1024, url=`https://speed.cloudflare.com/__down?bytes=${bytes}&cache=${Date.now()}`; const t=performance.now();
 try{const r=await fetch(url,{cache:"no-store"});const ab=await r.arrayBuffer();const sec=(performance.now()-t)/1000;const mbps=(ab.byteLength*8/sec/1e6);$("#speedResult").textContent=mbps.toFixed(1)+" Mbps";mark("network","ok",`Speed test ≈ ${mbps.toFixed(1)} Mbps`)}
 catch{$("#speedResult").textContent="Test failed";issue("warn","Speed test failed","The test endpoint may be blocked by the network/browser.")}
 btn.disabled=false
}
let chargeStart=null;
async function chargeTest(){
 const b=state.battery||await getBattery();state.battery=b;if(!b){$("#chargeResult").textContent="Battery API unavailable";return}
 chargeStart={level:b.level,time:Date.now()};$("#chargeResult").textContent=`Started at ${Math.round(b.level*100)}%. Keep the phone connected and tap Start again later.`;
 if(b.charging) toast("Charging detected");
}
async function benchmark(){
 $("#benchResult").textContent="Running…";const start=performance.now();let n=0;const target=performance.now()+1200;let x=1;
 while(performance.now()<target){x=(x*1.000001+Math.sin(n))*0.999999;n++}
 const ms=performance.now()-start;const score=Math.round(n*1000/ms);$("#benchResult").textContent=`MD Score ${score.toLocaleString()}`;mark("performance","ok",`Browser benchmark: ${score.toLocaleString()} operations/ms-style score. Not AnTuTu.`)
}
async function fullScan(){
 if("Notification" in window && Notification.permission==="default") { await requestPermission("notifications"); }
 state.issues=[];renderReport();$("#overall").textContent="Scanning…";$("#overallSub").textContent="Checking every test available to this browser/device.";
 await batteryTest();await networkTest();deviceTest();securityTest();soundTest();
 mark("charging",state.battery?.charging?"ok":"warn",state.battery?`${state.battery.charging?"Charging":"Not charging"} • exact wattage requires native APIs`:"Battery API unavailable");
 const bad=document.querySelectorAll(".bad").length,warn=document.querySelectorAll(".warn").length;
 const score=Math.max(0,100-bad*25-warn*8);$("#healthScore").textContent=score;
 $("#overall").textContent=bad?"Problems detected":warn?"Needs attention":"Looks healthy";
 $("#overallSub").textContent=`${bad} critical, ${warn} warning(s). See the report for details.`;
 toast("Full scan complete");
}
function notify(title,body){if("Notification" in window&&Notification.permission==="granted")new Notification(title,{body});}
$("#scanAll").onclick=fullScan;$("#speedTest").onclick=speedTest;$("#chargeTest").onclick=chargeTest;$("#benchmark").onclick=benchmark;
$("#clearReport").onclick=()=>{state.issues=[];renderReport()};
$("#closeDisplay").onclick=()=>$("#displayModal").classList.add("hidden");
$$("[data-test]").forEach(b=>b.onclick=()=>({display:displayTest,sound:soundTest,vibration:vibrationTest,network:networkTest,battery:batteryTest}[b.dataset.test])());

function permissionState(name, value){
 const el=$("#perm-"+name); if(!el)return;
 const labels={granted:"Allowed ✓",denied:"Denied",prompt:"Ask when needed",unsupported:"Not supported",default:"Not requested"};
 el.textContent=labels[value]||value||"Not requested";
}
async function requestPermission(type){
 if(window.AndroidDoctor && (type==="notifications" || type==="location" || type==="microphone")){
   AndroidDoctor.requestPermissions();
   $("#permissionMessage").textContent="Android permission dialog requested. Choose Allow or Deny.";
   return;
 }

 try{
  if(type==="notifications"){
    if(!("Notification" in window)){permissionState("notification","unsupported");$("#permissionMessage").textContent="This browser does not support notifications.";return}
    const p=await Notification.requestPermission();permissionState("notification",p);
    $("#permissionMessage").textContent=p==="granted"?"Notifications are allowed.":"Notifications were not allowed. You can still use Mobile Doctor.";
  }else if(type==="location"){
    if(!navigator.geolocation){permissionState("location","unsupported");return}
    navigator.geolocation.getCurrentPosition(
      ()=>{permissionState("location","granted");$("#permissionMessage").textContent="Location permission granted. Mobile Doctor does not store your location in this web app.";},
      e=>{permissionState("location",e.code===1?"denied":"prompt");$("#permissionMessage").textContent="Location was not granted. Wi‑Fi/network features that require location may be limited.";},
      {enableHighAccuracy:false,timeout:8000}
    );
  }else if(type==="microphone"){
    if(!navigator.mediaDevices?.getUserMedia){permissionState("microphone","unsupported");return}
    const stream=await navigator.mediaDevices.getUserMedia({audio:true});
    stream.getTracks().forEach(t=>t.stop());permissionState("microphone","granted");
    $("#permissionMessage").textContent="Microphone permission granted. The microphone is not kept active after the test.";
  }else if(type==="vibration"){
    if(navigator.vibrate){navigator.vibrate([150,80,150]);permissionState("vibration","granted");$("#permissionMessage").textContent="Vibration command sent. Check whether your phone vibrates."}
    else {permissionState("vibration","unsupported");$("#permissionMessage").textContent="Vibration API is unavailable in this browser."}
  }
 }catch(e){
  const map={notifications:"notification",location:"location",microphone:"microphone"}; 
  permissionState(map[type]||type,"denied");$("#permissionMessage").textContent="Permission request was cancelled or denied.";
 }
}
function refreshPermissionStates(){
 permissionState("notification",("Notification"in window)?Notification.permission:"unsupported");
 permissionState("vibration",navigator.vibrate?"prompt":"unsupported");
 if(navigator.permissions?.query){
   navigator.permissions.query({name:"geolocation"}).then(x=>permissionState("location",x.state)).catch(()=>{});
   navigator.permissions.query({name:"microphone"}).then(x=>permissionState("microphone",x.state)).catch(()=>{});
 }
}
$$("[data-permission]").forEach(b=>b.onclick=()=>requestPermission(b.dataset.permission));
refreshPermissionStates();

$("#savePrefs").onclick=async()=>{localStorage.highLimit=$("#highLimit").value;localStorage.lowLimit=$("#lowLimit").value;localStorage.restMins=$("#restMins").value;if("Notification"in window&&Notification.permission==="default")await Notification.requestPermission();toast("Preferences saved");startRestReminder()};
$("#highLimit").value=localStorage.highLimit||80;$("#lowLimit").value=localStorage.lowLimit||25;$("#restMins").value=localStorage.restMins||90;
function startRestReminder(){clearInterval(state.restTimer);const mins=Number(localStorage.restMins||90);state.restTimer=setInterval(()=>notify("Mobile Doctor","You've been using your phone continuously. Consider taking a short rest."),mins*60000)}

// Native Android bridge: real device data when the APK is running.
window.nativePermissions = function(raw){
  try{
    const p=JSON.parse(raw);
    ["notification","location","microphone"].forEach(k=>{
      const v=p[k==="notification"?"notifications":k];
      if(typeof permissionState==="function") permissionState(k,v);
    });
    const msg=$("#permissionMessage"); if(msg) msg.textContent="Android permission status updated.";
  }catch(e){}
};
function nativeBattery(){
  if(window.AndroidDoctor?.batteryInfo){
    try{
      const b=JSON.parse(AndroidDoctor.batteryInfo());
      $("#mBattery").textContent=(b.capacity>=0?b.capacity:b.level)+"%";
      $("#mCharging").textContent=b.charging?"Charging":"Not charging";
      if(b.temperatureC!==null) mark("battery",b.temperatureC>=45?"bad":b.temperatureC>=40?"warn":"ok",
        `${b.capacity}% • ${b.charging?"Charging":"Not charging"} • ${b.temperatureC.toFixed(1)}°C • ${b.voltageMv}mV`);
      return b;
    }catch(e){}
  }
  return null;
}
function nativeDevice(){
  if(window.AndroidDoctor?.deviceInfo){
    try{
      const d=JSON.parse(AndroidDoctor.deviceInfo());
      $("#mScreen").textContent=`${d.screenWidth}×${d.screenHeight}`;
      $("#mMemory").textContent=`${d.cores} cores`;
      mark("device","ok",`${d.manufacturer} ${d.model} • Android ${d.android} • ${d.screenWidth}×${d.screenHeight}`);
      return d;
    }catch(e){}
  }
  return null;
}
function nativeNetwork(){
  if(window.AndroidDoctor?.networkInfo){
    try{
      const n=JSON.parse(AndroidDoctor.networkInfo());
      $("#mNetwork").textContent=n.online?"Online":"Offline";
      $("#mConnection").textContent=n.wifi?"Wi‑Fi":n.cellular?"Mobile":"Other";
      mark("network",n.online?"ok":"bad",n.online?`${n.wifi?"Wi‑Fi":n.cellular?"Mobile data":"Network"} • ↓ ${n.downstreamKbps} kbps • ↑ ${n.upstreamKbps} kbps`:"Offline");
      return n;
    }catch(e){}
  }
  return null;
}
if(window.AndroidDoctor){
  const oldBatteryTest=batteryTest;
  batteryTest=async function(){ const b=nativeBattery(); if(b)return; return oldBatteryTest(); };
  const oldNetworkTest=networkTest;
  networkTest=async function(){ const n=nativeNetwork(); if(n)return; return oldNetworkTest(); };
  const oldDeviceTest=deviceTest;
  deviceTest=function(){ const d=nativeDevice(); if(d)return; oldDeviceTest(); };
}

async function tick(){
 $("#clock").textContent=new Date().toLocaleTimeString();
 const b=state.battery||await getBattery();if(b){state.battery=b;$("#mBattery").textContent=Math.round(b.level*100)+"%";$("#mCharging").textContent=b.charging?"Charging":"Not charging"}
 $("#mNetwork").textContent=navigator.onLine?"Online":"Offline";
}
setInterval(()=>{ tick(); if(window.AndroidDoctor) nativeBattery(); },1000);tick();startRestReminder();
if(window.AndroidDoctor){ nativeBattery(); nativeDevice(); nativeNetwork(); }
if(state.battery)state.battery.addEventListener?.("levelchange",tick);
window.addEventListener("online",networkTest);window.addEventListener("offline",networkTest);
